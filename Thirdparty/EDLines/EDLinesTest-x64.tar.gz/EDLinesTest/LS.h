#ifndef _LS_H_
#define _LS_H_
  
struct LS {
  double sx, sy, ex, ey; // Start & end coordinates of the line segment
};

#endif